# Employee Monitor — Version 1.0 starter

A transparent, consent-based employee attendance and work-activity monitoring starter for Windows 10/11 and a cloud admin panel.

## Included
- FastAPI backend with SQLite for local development (PostgreSQL URL supported)
- Admin-protected dashboard API
- Device enrollment using a per-device token
- Windows agent prototype: foreground application name, idle/active state, heartbeat
- Optional monitoring of explicitly configured work folders for file create/modify/rename/delete events
- Simple browser dashboard

## Privacy and scope
Deploy only on company-owned or company-managed devices with employee notice and appropriate authorization.
The starter does **not** capture keystrokes, screenshots, document contents, passwords, private browsing content, or arbitrary personal folders.
File monitoring is limited to folders explicitly configured by the administrator. The first version records file-system change events; it does not claim to reliably detect every file-open/file-close event.
The agent displays a tray/console status and is not designed to hide itself.

## Architecture
Windows Agent -> HTTPS FastAPI API -> PostgreSQL (production) / SQLite (local) -> Admin Dashboard

## Run the server locally
Python 3.11+ recommended.

```bash
cd server
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Set environment variables:
- `ADMIN_TOKEN`: long random secret for admin API access
- `DATABASE_URL`: optional SQLAlchemy URL; default is local SQLite
- `ENROLLMENT_CODE`: one-time/company enrollment code used to register a new laptop

Example (PowerShell):
```powershell
$env:ADMIN_TOKEN="replace-with-a-long-random-secret"
$env:ENROLLMENT_CODE="replace-with-a-separate-enrollment-secret"
uvicorn app:app --host 127.0.0.1 --port 8000
```

Open `dashboard/index.html` in a browser. Enter the `ADMIN_TOKEN`.
For local testing, enroll a device using the API:
```bash
curl -X POST http://127.0.0.1:8000/api/enroll \
  -H "Content-Type: application/json" \
  -d "{\"enrollment_code\":\"YOUR_ENROLLMENT_CODE\",\"device_name\":\"TEST-LAPTOP\",\"employee_name\":\"Demo Employee\"}"
```
Copy the returned `device_token` into the agent config.

## Run the Windows agent
```bash
cd agent
pip install -r requirements.txt
copy config.example.json config.json
```
Edit `config.json` with the API URL, device token, and approved work folders, then:
```bash
python agent.py
```

The agent requires Windows. `pywin32` is used for foreground application and idle-time detection. File monitoring uses `watchdog`.

## Production checklist before rollout
1. Deploy the API behind HTTPS on a managed cloud host.
2. Use managed PostgreSQL, backups, and database encryption at rest.
3. Replace the simple shared admin token with named admin accounts, MFA, and role-based access.
4. Add device-token rotation/revocation and enrollment approval.
5. Publish an employee monitoring notice and define retention/access policies.
6. Package and sign the Windows agent installer; test on a small pilot group first.
7. Add Windows service/session handling and robust startup/shutdown event handling.
8. Validate Windows 10 compatibility on the exact builds in use.

This is a development starter, not a production-ready employee surveillance product.
