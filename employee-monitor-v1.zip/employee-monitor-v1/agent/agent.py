import json
import os
import platform
import socket
import time
import threading
from datetime import datetime, timezone
from pathlib import Path

import psutil
import requests
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

CONFIG_PATH = Path(__file__).with_name("config.json")

def utcnow():
    return datetime.now(timezone.utc).isoformat()

def load_config():
    if not CONFIG_PATH.exists():
        raise SystemExit("Create config.json from config.example.json first.")
    cfg = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    if not cfg.get("server_url", "").startswith("https://") and "localhost" not in cfg.get("server_url", "") and "127.0.0.1" not in cfg.get("server_url", ""):
        raise SystemExit("Use HTTPS for cloud server_url.")
    if not cfg.get("device_token"):
        raise SystemExit("Set device_token in config.json.")
    return cfg

def windows_activity():
    if platform.system() != "Windows":
        return None, None
    try:
        import win32gui, win32process, win32api
        hwnd = win32gui.GetForegroundWindow()
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        app = psutil.Process(pid).name() if pid else None
        class LASTINPUTINFO:
            pass
        import ctypes
        class LASTINPUTINFO(ctypes.Structure):
            _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]
        lii = LASTINPUTINFO()
        lii.cbSize = ctypes.sizeof(LASTINPUTINFO)
        ctypes.windll.user32.GetLastInputInfo(ctypes.byref(lii))
        tick = ctypes.windll.kernel32.GetTickCount()
        idle_seconds = max(0, (tick - lii.dwTime) / 1000.0)
        return app, idle_seconds >= 300
    except Exception:
        return None, None

def send(cfg, path, payload):
    url = cfg["server_url"].rstrip("/") + path
    headers = {"X-Device-Token": cfg["device_token"]}
    try:
        r = requests.post(url, json=payload, headers=headers, timeout=10)
        r.raise_for_status()
        return True
    except requests.RequestException as exc:
        print(f"Network/API error: {exc}")
        return False


class WorkFolderHandler(FileSystemEventHandler):
    """Records file-system change metadata only in admin-approved folders."""
    def __init__(self, cfg):
        self.cfg = cfg

    def on_created(self, event):
        if not event.is_directory:
            self._record("file_created", event.src_path)

    def on_modified(self, event):
        if not event.is_directory:
            self._record("file_modified", event.src_path)

    def on_deleted(self, event):
        if not event.is_directory:
            self._record("file_deleted", event.src_path)

    def on_moved(self, event):
        if not event.is_directory:
            self._record("file_renamed_or_moved", event.dest_path,
                         details=f"Moved from {event.src_path}")

    def _record(self, event_type, path, details=None):
        # File names/paths are metadata; file contents are never opened or uploaded.
        send(self.cfg, "/api/events", {"events": [{
            "event_type": event_type,
            "file_name": os.path.basename(path),
            "details": details or "Change detected in an administrator-approved work folder.",
            "occurred_at": utcnow()
        }]})

def start_folder_watchers(cfg):
    observer = Observer()
    handler = WorkFolderHandler(cfg)
    for folder in cfg.get("approved_work_folders", []):
        p = Path(folder)
        if p.exists() and p.is_dir():
            observer.schedule(handler, str(p), recursive=True)
            print(f"Watching approved work folder: {p}")
        else:
            print(f"Skipping missing work folder: {p}")
    observer.start()
    return observer

def main():
    cfg = load_config()
    print("Employee Monitor agent running visibly. Press Ctrl+C to stop.")
    print(f"Device: {socket.gethostname()} | OS: {platform.platform()}")
    observer = start_folder_watchers(cfg)
    send(cfg, "/api/events", {"events": [{"event_type": "agent_started", "details": "Monitoring agent started by the employee/company-managed startup configuration.", "occurred_at": utcnow()}]})
    last_heartbeat = 0
    last_app = None
    last_idle = None
    try:
      while True:
        now = time.time()
        if now - last_heartbeat >= int(cfg.get("heartbeat_seconds", 45)):
            send(cfg, "/api/heartbeat", {})
            last_heartbeat = now
        app, idle = windows_activity()
        if app != last_app or idle != last_idle:
            event = {
                "event_type": "application_focus" if app != last_app else "idle_state",
                "app_name": app,
                "idle": idle,
                "details": "Foreground application process name; no window title or document content collected.",
                "occurred_at": utcnow()
            }
            send(cfg, "/api/events", {"events": [event]})
            last_app, last_idle = app, idle
        time.sleep(max(5, int(cfg.get("poll_seconds", 15))))
    except KeyboardInterrupt:
      print("Stopping agent...")
    finally:
      observer.stop()
      observer.join(timeout=5)

if __name__ == "__main__":
    main()
